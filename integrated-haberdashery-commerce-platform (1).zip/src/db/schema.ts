import { pgTable, text, serial, integer, numeric, timestamp, boolean } from "drizzle-orm/pg-core";

// ==========================================
// 1. KULLANICILAR & ROLLER
// ==========================================
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("CASHIER"), // SUPER_ADMIN, STORE_MANAGER, WAREHOUSE_KEEPER, CASHIER, B2B_CUSTOMER, B2C_CUSTOMER
  phone: text("phone"),
  avatarUrl: text("avatar_url"),
  customerId: integer("customer_id"), // B2B portal müşterisinin cari karta bağlantısı
  // --- Güvenlik / 2FA alanları ---
  totpSecret: text("totp_secret"), // Google Authenticator base32 gizli anahtarı
  totpSecretPrevious: text("totp_secret_previous"), // Rotasyon sırasında eski kod da kabul edilir (kilitlenmeyi önler)
  mfaEnabled: boolean("mfa_enabled").notNull().default(false),
  recoveryCodeHash: text("recovery_code_hash"), // Tek kullanımlık kurtarma kodu özeti
  failedLoginCount: integer("failed_login_count").notNull().default(0),
  lockedUntil: timestamp("locked_until"), // Brute-force hesap kilidi
  lastLoginAt: timestamp("last_login_at"),
  passwordChangedAt: timestamp("password_changed_at"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// OTURUM (SESSION) YÖNETİMİ — token iptali (revocation) ve cihaz takibi
export const adminSessions = pgTable("admin_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  jti: text("jti").notNull().unique(), // Token JWT-ID
  ip: text("ip"),
  userAgent: text("user_agent"),
  mfaVerified: boolean("mfa_verified").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  revokedAt: timestamp("revoked_at"),
});

// TEK KULLANIMLIK GİRİŞ DOĞRULAMA NONCE'LARI (pre-auth / enrollment)
export const authNonces = pgTable("auth_nonces", {
  id: serial("id").primaryKey(),
  tokenHash: text("token_hash").notNull().unique(),
  userId: integer("user_id").notNull(),
  scope: text("scope").notNull(), // PRE_AUTH | ENROLL
  attemptCount: integer("attempt_count").notNull().default(0),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

// ==========================================
// 2. MÜŞTERİLER (B2C & B2B) & CRM
// ==========================================
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  type: text("type").notNull().default("B2C"), // B2C, B2B
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  companyName: text("company_name"),
  taxOffice: text("tax_office"),
  taxNumber: text("tax_number"),
  creditLimit: numeric("credit_limit", { precision: 12, scale: 2 }).default("0.00"),
  balance: numeric("balance", { precision: 12, scale: 2 }).default("0.00"), // Cari Bakiye
  loyaltyPoints: integer("loyalty_points").default(0).notNull(),
  segment: text("segment").default("YENİ"), // YENİ, AKTİF, VİP, TOPTANCI, RİSKLİ
  discountRate: numeric("discount_rate", { precision: 5, scale: 2 }).default("0.00"), // Özel B2B iskontosu
  // --- FAZ 9: B2B cari & fiyatlandırma ---
  priceListId: integer("price_list_id"), // atanmış fiyat listesi
  paymentTermDays: integer("payment_term_days").default(30).notNull(), // vade (gün)
  minOrderAmount: numeric("min_order_amount", { precision: 10, scale: 2 }).default("0.00"),
  isBlocked: boolean("is_blocked").notNull().default(false), // riskli/kapalı cari
  approvalStatus: text("approval_status").default("APPROVED"), // PENDING, APPROVED, REJECTED
  address: text("address"),
  city: text("city"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 3. KATEGORİLER & MARKALAR
// ==========================================
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  parentId: integer("parent_id"),
  icon: text("icon"),
  description: text("description"),
  displayOrder: integer("display_order").default(0),
  isActive: boolean("is_active").notNull().default(true),
});

export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  logoUrl: text("logo_url"),
  isActive: boolean("is_active").notNull().default(true),
});

// ==========================================
// 4. ÜRÜNLER & VARYANTLAR
// ==========================================
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  sku: text("sku").notNull().unique(),
  barcode: text("barcode").unique(),
  brandId: integer("brand_id"),
  categoryId: integer("category_id").notNull(),
  shortDescription: text("short_description"),
  description: text("description"),
  unit: text("unit").default("Adet").notNull(), // Adet, Metre, Paket, Kutu, Rulo, Bobin
  buyPrice: numeric("buy_price", { precision: 10, scale: 2 }).notNull().default("0.00"),
  retailPrice: numeric("retail_price", { precision: 10, scale: 2 }).notNull().default("0.00"),
  b2bPrice: numeric("b2b_price", { precision: 10, scale: 2 }).notNull().default("0.00"),
  minOrderQty: integer("min_order_qty").default(1).notNull(),
  packageQty: integer("package_qty").default(1).notNull(), // Paket içi adet
  vatRate: integer("vat_rate").default(20).notNull(), // KDV %10 veya %20
  hasVariants: boolean("has_variants").default(false).notNull(),
  imageUrl: text("image_url"),
  campaignPrice: numeric("campaign_price", { precision: 10, scale: 2 }),
  tags: text("tags"), // virgülle ayrılmış etiketler: "fermuar,siyah,mont"
  collection: text("collection"),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  isFeatured: boolean("is_featured").default(false),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const productImages = pgTable("product_images", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  url: text("url").notNull(),
  altText: text("alt_text"),
  sortOrder: integer("sort_order").default(0).notNull(),
  isPrimary: boolean("is_primary").default(false).notNull(),
});

export const productVariants = pgTable("product_variants", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  sku: text("sku").notNull().unique(),
  barcode: text("barcode").unique(),
  colorName: text("color_name"),
  colorHex: text("color_hex"),
  size: text("size"), // e.g., "20 cm", "40 mm", "No: 50"
  length: text("length"), // e.g., "100m", "500m"
  buyPrice: numeric("buy_price", { precision: 10, scale: 2 }),
  retailPrice: numeric("retail_price", { precision: 10, scale: 2 }).notNull(),
  b2bPrice: numeric("b2b_price", { precision: 10, scale: 2 }),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true).notNull(),
});

// ==========================================
// 5. DEPOLAR, RAF/LOKASYON & STOK
// ==========================================
export const warehouses = pgTable("warehouses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(), // MRK, KDK-MAG, ONL-DEP, TOPTAN
  type: text("type").notNull().default("STORE"), // CENTRAL, STORE, ONLINE, WHOLESALE
  address: text("address"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const warehouseLocations = pgTable("warehouse_locations", {
  id: serial("id").primaryKey(),
  warehouseId: integer("warehouse_id").notNull(),
  locationCode: text("location_code").notNull(), // MRK-A-03-12
  zone: text("zone"),
  aisle: text("aisle"),
  rack: text("rack"),
  shelf: text("shelf"),
  bin: text("bin"),
});

export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  warehouseId: integer("warehouse_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  physicalQty: integer("physical_qty").notNull().default(0),
  reservedQty: integer("reserved_qty").notNull().default(0),
  minStock: integer("min_stock").notNull().default(10),
  maxStock: integer("max_stock").notNull().default(500),
  reorderPoint: integer("reorder_point").notNull().default(15),
  locationCode: text("location_code").default("GENEL-A-01"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// STOK REZERVASYONLARI — checkout/sepet bazlı süreli stok kilitleme (FAZ 3)
export const inventoryReservations = pgTable("inventory_reservations", {
  id: serial("id").primaryKey(),
  warehouseId: integer("warehouse_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  qty: integer("qty").notNull(),
  referenceType: text("reference_type").notNull().default("CART"), // CART, CHECKOUT, ORDER
  referenceId: text("reference_id"), // sepet/checkout anahtarı veya sipariş no
  status: text("status").notNull().default("ACTIVE"), // ACTIVE, CONSUMED, RELEASED, EXPIRED
  expiresAt: timestamp("expires_at").notNull(),
  createdBy: text("created_by").default("Sistem"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// DEPOLAR ARASI TRANSFER İŞ AKIŞI: REQUESTED → APPROVED → SHIPPED → RECEIVED (FAZ 3)
export const stockTransfers = pgTable("stock_transfers", {
  id: serial("id").primaryKey(),
  transferNumber: text("transfer_number").notNull().unique(), // TRF-2026-001
  fromWarehouseId: integer("from_warehouse_id").notNull(),
  toWarehouseId: integer("to_warehouse_id").notNull(),
  status: text("status").notNull().default("REQUESTED"), // REQUESTED, APPROVED, SHIPPED, RECEIVED, CANCELLED
  note: text("note"),
  createdBy: text("created_by").default("Depo Sorumlusu"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  shippedAt: timestamp("shipped_at"),
  receivedAt: timestamp("received_at"),
});

export const stockTransferItems = pgTable("stock_transfer_items", {
  id: serial("id").primaryKey(),
  transferId: integer("transfer_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  qty: integer("qty").notNull(),
});

// STOK SAYIM OTURUMLARI — barkod taramalı sayım ve fark mutabakatı (FAZ 3)
export const stockCountSessions = pgTable("stock_count_sessions", {
  id: serial("id").primaryKey(),
  countNumber: text("count_number").notNull().unique(), // COUNT-2026-001
  warehouseId: integer("warehouse_id").notNull(),
  status: text("status").notNull().default("IN_PROGRESS"), // IN_PROGRESS, COMPLETED, CANCELLED
  startedBy: text("started_by").default("Sayım Ekibi"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const stockCountItems = pgTable("stock_count_items", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  expectedQty: integer("expected_qty").notNull(),
  countedQty: integer("counted_qty").notNull(),
  locationCode: text("location_code"),
  scannedBarcode: text("scanned_barcode"),
  countedAt: timestamp("counted_at").defaultNow().notNull(),
});

// STOK HAREKET DEFTERİ (STOCK LEDGER)
export const inventoryLedger = pgTable("inventory_ledger", {
  id: serial("id").primaryKey(),
  transactionType: text("transaction_type").notNull(), // PURCHASE, SALE, RETURN, TRANSFER_IN, TRANSFER_OUT, ADJUSTMENT, COUNT_DIFF, DAMAGE, RESERVATION
  warehouseId: integer("warehouse_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  quantity: integer("quantity").notNull(), // + veya -
  unitCost: numeric("unit_cost", { precision: 10, scale: 2 }).default("0.00"),
  referenceType: text("reference_type"), // ORDER, POS_SALE, PO, TRANSFER, ADJUSTMENT
  referenceId: text("reference_id"),
  note: text("note"),
  createdBy: text("created_by").default("Sistem"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 6. SİPARİŞLER (E-TİCARET, B2B, POS)
// ==========================================
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(), // OR-2026-001, POS-2026-042
  orderType: text("order_type").notNull().default("ONLINE_B2C"), // ONLINE_B2C, B2B, POS
  customerId: integer("customer_id"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  customerPhone: text("customer_phone"),
  status: text("status").notNull().default("PAID"), // PENDING, PAID, PREPARING, READY_FOR_SHIPMENT, SHIPPED, DELIVERED, CANCELLED, REFUNDED
  paymentStatus: text("payment_status").notNull().default("PAID"), // PENDING, PAID, PARTIAL, REFUNDED
  paymentMethod: text("payment_method").notNull().default("CREDIT_CARD"), // CREDIT_CARD, CASH, EFT_HAVALE, B2B_CREDIT, SPLIT
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull().default("0.00"),
  discountTotal: numeric("discount_total", { precision: 10, scale: 2 }).notNull().default("0.00"),
  taxTotal: numeric("tax_total", { precision: 10, scale: 2 }).notNull().default("0.00"),
  shippingTotal: numeric("shipping_total", { precision: 10, scale: 2 }).notNull().default("0.00"),
  grandTotal: numeric("grand_total", { precision: 10, scale: 2 }).notNull().default("0.00"),
  shippingAddress: text("shipping_address"),
  trackingNumber: text("tracking_number"),
  carrier: text("carrier").default("Yurtiçi Kargo"),
  posShiftId: integer("pos_shift_id"),
  erpInvoiceNumber: text("erp_invoice_number"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  productName: text("product_name").notNull(),
  variantName: text("variant_name"),
  sku: text("sku").notNull(),
  barcode: text("barcode"),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  quantity: integer("quantity").notNull(),
  taxRate: integer("tax_rate").notNull().default(20),
  totalPrice: numeric("total_price", { precision: 10, scale: 2 }).notNull(),
});

// SİPARİŞ DURUM GEÇMİŞİ (audit trail) — FAZ 4
export const orderStatusHistory = pgTable("order_status_history", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  fromStatus: text("from_status"),
  toStatus: text("to_status").notNull(),
  note: text("note"),
  changedBy: text("changed_by").default("Sistem"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// İADELER (RMA) — FAZ 4
export const orderReturns = pgTable("order_returns", {
  id: serial("id").primaryKey(),
  returnNumber: text("return_number").notNull().unique(), // IAD-2026-001
  orderId: integer("order_id").notNull(),
  orderNumber: text("order_number").notNull(),
  reason: text("reason"),
  status: text("status").notNull().default("REQUESTED"), // REQUESTED, APPROVED, RECEIVED, REFUNDED, REJECTED
  refundAmount: numeric("refund_amount", { precision: 10, scale: 2 }).default("0.00"),
  restock: boolean("restock").notNull().default(true),
  warehouseId: integer("warehouse_id").default(3),
  createdBy: text("created_by").default("Müşteri Hizmetleri"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const orderReturnItems = pgTable("order_return_items", {
  id: serial("id").primaryKey(),
  returnId: integer("return_id").notNull(),
  orderItemId: integer("order_item_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  refundAmount: numeric("refund_amount", { precision: 10, scale: 2 }).notNull().default("0.00"),
});

// ==========================================
// 7. POS VARDİYA & KASA YÖNETİMİ — FAZ 7
// ==========================================
export const posShifts = pgTable("pos_shifts", {
  id: serial("id").primaryKey(),
  shiftNumber: text("shift_number"), // VARD-2026-001
  terminalCode: text("terminal_code").default("KASA-01").notNull(),
  cashierName: text("cashier_name").notNull(),
  warehouseId: integer("warehouse_id").notNull(),
  openingAmount: numeric("opening_amount", { precision: 10, scale: 2 }).notNull().default("500.00"),
  closingAmount: numeric("closing_amount", { precision: 10, scale: 2 }),
  expectedAmount: numeric("expected_amount", { precision: 10, scale: 2 }),
  totalSalesCash: numeric("total_sales_cash", { precision: 10, scale: 2 }).default("0.00"),
  totalSalesCard: numeric("total_sales_card", { precision: 10, scale: 2 }).default("0.00"),
  totalSalesSplit: numeric("total_sales_split", { precision: 10, scale: 2 }).default("0.00"),
  totalReturnsCash: numeric("total_returns_cash", { precision: 10, scale: 2 }).default("0.00"),
  totalReturnsCard: numeric("total_returns_card", { precision: 10, scale: 2 }).default("0.00"),
  cashInTotal: numeric("cash_in_total", { precision: 10, scale: 2 }).default("0.00"),
  cashOutTotal: numeric("cash_out_total", { precision: 10, scale: 2 }).default("0.00"),
  status: text("status").notNull().default("OPEN"), // OPEN, CLOSED
  zReportNumber: text("z_report_number"), // Z-2026-001
  openedAt: timestamp("opened_at").defaultNow().notNull(),
  closedAt: timestamp("closed_at"),
  notes: text("notes"),
});

// KASA HAREKETLERİ (Nakit Giriş / Çıkış / Masraf / Avans) — FAZ 7
export const posCashTransactions = pgTable("pos_cash_transactions", {
  id: serial("id").primaryKey(),
  shiftId: integer("shift_id").notNull(),
  warehouseId: integer("warehouse_id").notNull(),
  type: text("type").notNull(), // CASH_IN, CASH_OUT, EXPENSE, FLOAT_ADD
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  reason: text("reason").notNull(),
  cashierName: text("cashier_name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 8. TEDARİKÇİ & SATIN ALMA YÖNETİMİ
// ==========================================
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  contactPerson: text("contact_person"),
  phone: text("phone"),
  email: text("email"),
  taxOffice: text("tax_office"),
  taxNumber: text("tax_number"),
  leadTimeDays: integer("lead_time_days").default(3).notNull(),
  paymentTerms: text("payment_terms").default("30 Gün Vade"),
  rating: numeric("rating", { precision: 3, scale: 1 }).default("4.8"),
  address: text("address"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  poNumber: text("po_number").notNull().unique(), // SAT-2026-001
  supplierId: integer("supplier_id").notNull(),
  warehouseId: integer("warehouse_id").notNull(),
  status: text("status").notNull().default("ORDERED"), // DRAFT, APPROVED, ORDERED, RECEIVED, CANCELLED
  totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).notNull().default("0.00"),
  notes: text("notes"),
  expectedDate: text("expected_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const purchaseOrderItems = pgTable("purchase_order_items", {
  id: serial("id").primaryKey(),
  purchaseOrderId: integer("purchase_order_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  quantity: integer("quantity").notNull(),
  unitCost: numeric("unit_cost", { precision: 10, scale: 2 }).notNull(),
  receivedQty: integer("received_qty").default(0).notNull(),
  totalCost: numeric("total_cost", { precision: 10, scale: 2 }).notNull(),
});

// SATIN ALMA TALEPLERİ — FAZ 6: REQUESTED → APPROVED → ORDERED → REJECTED
export const purchaseRequests = pgTable("purchase_requests", {
  id: serial("id").primaryKey(),
  requestNumber: text("request_number").notNull().unique(), // TAL-2026-001
  warehouseId: integer("warehouse_id").notNull(),
  status: text("status").notNull().default("REQUESTED"), // REQUESTED, APPROVED, ORDERED, REJECTED
  priority: text("priority").notNull().default("NORMAL"), // LOW, NORMAL, HIGH, URGENT
  notes: text("notes"),
  createdBy: text("created_by").default("Depo Sorumlusu"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  approvedBy: text("approved_by"),
});

export const purchaseRequestItems = pgTable("purchase_request_items", {
  id: serial("id").primaryKey(),
  requestId: integer("request_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  qty: integer("qty").notNull(),
  estimatedCost: numeric("estimated_cost", { precision: 10, scale: 2 }).default("0.00"),
});

// MAL KABUL FİŞLERİ — FAZ 6: kısmi kabul takibi
export const goodsReceipts = pgTable("goods_receipts", {
  id: serial("id").primaryKey(),
  receiptNumber: text("receipt_number").notNull().unique(), // MK-2026-001
  purchaseOrderId: integer("purchase_order_id").notNull(),
  warehouseId: integer("warehouse_id").notNull(),
  receivedBy: text("received_by").default("Mal Kabul Görevlisi"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const goodsReceiptItems = pgTable("goods_receipt_items", {
  id: serial("id").primaryKey(),
  receiptId: integer("receipt_id").notNull(),
  purchaseOrderItemId: integer("purchase_order_item_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  qty: integer("qty").notNull(),
});

// ==========================================
// 8.5 B2B: FİYAT LİSTELERİ, KADEMELİ FİYAT & CARİ HESAP (FAZ 9)
// ==========================================
export const priceLists = pgTable("price_lists", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // RETAIL, DEALER, WHOLESALE, VIP
  name: text("name").notNull(),
  description: text("description"),
  // Liste geneli varsayılan iskonto (ürün bazlı override yoksa uygulanır)
  defaultDiscountRate: numeric("default_discount_rate", { precision: 5, scale: 2 }).default("0.00").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Ürün bazlı özel fiyat (liste × ürün)
export const priceListItems = pgTable("price_list_items", {
  id: serial("id").primaryKey(),
  priceListId: integer("price_list_id").notNull(),
  productId: integer("product_id").notNull(),
  variantId: integer("variant_id"),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  minQty: integer("min_qty").default(1).notNull(),
});

// Kademeli (hacim) fiyat baremleri: 1-9 / 10-49 / 50-99 / 100+
export const priceTiers = pgTable("price_tiers", {
  id: serial("id").primaryKey(),
  priceListId: integer("price_list_id").notNull(),
  productId: integer("product_id"), // null = liste geneli barem
  minQty: integer("min_qty").notNull(),
  maxQty: integer("max_qty"), // null = üst sınırsız
  discountRate: numeric("discount_rate", { precision: 5, scale: 2 }), // yüzde iskonto
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }), // ya da sabit birim fiyat
});

// CARİ HESAP HAREKETLERİ (borç/alacak defteri)
export const accountTransactions = pgTable("account_transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  type: text("type").notNull(), // DEBIT (borç: satış), CREDIT (alacak: tahsilat), ADJUSTMENT
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }).notNull(),
  referenceType: text("reference_type"), // ORDER, PAYMENT, MANUAL
  referenceId: text("reference_id"),
  description: text("description"),
  dueDate: timestamp("due_date"), // vade tarihi (satış için)
  paidAt: timestamp("paid_at"),
  createdBy: text("created_by").default("Sistem"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 9. KAMPANYALAR, KUPONLAR & SADAKAT
// ==========================================
// KAMPANYALAR — kural tabanlı promosyon motoru (FAZ 8)
// ruleType: PERCENT_CATEGORY | PERCENT_BRAND | THRESHOLD_DISCOUNT | BUY_X_PAY_Y | FREE_SHIPPING | BUNDLE_PERCENT
export const promotions = pgTable("promotions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  ruleType: text("rule_type").notNull().default("PERCENT_CATEGORY"),
  // Hedef tanımlayıcılar
  categoryId: integer("category_id"),
  brandId: integer("brand_id"),
  productId: integer("product_id"),
  // Kural parametreleri
  percentValue: numeric("percent_value", { precision: 5, scale: 2 }),
  fixedValue: numeric("fixed_value", { precision: 10, scale: 2 }),
  thresholdAmount: numeric("threshold_amount", { precision: 10, scale: 2 }), // ör. 1000 TL üzeri
  buyQty: integer("buy_qty"),
  payQty: integer("pay_qty"),
  minQty: integer("min_qty").default(1),
  maxDiscount: numeric("max_discount", { precision: 10, scale: 2 }),
  freeShipping: boolean("free_shipping").notNull().default(false),
  priority: integer("priority").default(50).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  isActive: boolean("is_active").notNull().default(true),
  usedCount: integer("used_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ÜRÜN YORUMLARI (moderasyonlu) — FAZ 8
export const productReviews = pgTable("product_reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  rating: integer("rating").notNull(), // 1..5
  title: text("title"),
  comment: text("comment").notNull(),
  verifiedPurchase: boolean("verified_purchase").notNull().default(false),
  status: text("status").notNull().default("PENDING"), // PENDING, APPROVED, REJECTED
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ÜRÜN SORU / CEVAP — FAZ 8
export const productQuestions = pgTable("product_questions", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  askerName: text("asker_name").notNull(),
  question: text("question").notNull(),
  answer: text("answer"),
  answeredBy: text("answered_by"),
  status: text("status").notNull().default("OPEN"), // OPEN, ANSWERED, HIDDEN
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  discountType: text("discount_type").notNull().default("PERCENT"), // PERCENT, FIXED
  discountValue: numeric("discount_value", { precision: 10, scale: 2 }).notNull(),
  minCartAmount: numeric("min_cart_amount", { precision: 10, scale: 2 }).default("0.00"),
  maxDiscount: numeric("max_discount", { precision: 10, scale: 2 }),
  usageLimit: integer("usage_limit").default(100),
  usedCount: integer("used_count").default(0),
  isActive: boolean("is_active").default(true).notNull(),
});

export const loyaltyTransactions = pgTable("loyalty_transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  points: integer("points").notNull(),
  type: text("type").notNull(), // EARN, SPEND, BONUS
  description: text("description"),
  orderId: integer("order_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ==========================================
// 10. CMS: BLOG & KURUMSAL İÇERİK
// ==========================================
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  category: text("category").default("Dikiş Rehberi"),
  author: text("author").default("Tuhafiye Uzmanı"),
  imageUrl: text("image_url"),
  isPublished: boolean("is_published").default(true).notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});

// ==========================================
// 11. ERP ENTEGRASYON KAYITLARI & AUDIT LOG (FAZ 10)
// ==========================================
export const erpSyncLogs = pgTable("erp_sync_logs", {
  id: serial("id").primaryKey(),
  provider: text("provider").default("LOGO_GO3").notNull(), // LOGO_GO3, MIKRO_FLY, NETSIS, PARASUT, GIB_PORTAL
  entityType: text("entity_type").notNull(), // CUSTOMER, INVOICE, PURCHASE_INVOICE, PAYMENT, STOCK, RECEIPT
  entityId: text("entity_id").notNull(),
  action: text("action").notNull(), // SYNC_SENT, SYNC_SUCCESS, SYNC_ERROR, RETRY
  status: text("status").notNull(), // SUCCESS, PENDING, FAILED, RETRYING
  retryCount: integer("retry_count").default(0).notNull(),
  errorMessage: text("error_message"),
  payload: text("payload"),
  response: text("response"),
  batchId: text("batch_id"),
  syncedAt: timestamp("synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ERP ASENKRON İŞ KUYRUĞU (Background Job Queue) — FAZ 10
export const erpSyncJobs = pgTable("erp_sync_jobs", {
  id: serial("id").primaryKey(),
  provider: text("provider").default("LOGO_GO3").notNull(),
  entityType: text("entity_type").notNull(), // CUSTOMER, INVOICE, PAYMENT, STOCK
  entityId: text("entity_id").notNull(),
  payload: text("payload").notNull(),
  status: text("status").default("PENDING").notNull(), // PENDING, PROCESSING, COMPLETED, FAILED
  priority: integer("priority").default(10).notNull(),
  attempts: integer("attempts").default(0).notNull(),
  maxAttempts: integer("max_attempts").default(3).notNull(),
  lastError: text("last_error"),
  nextRunAt: timestamp("next_run_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// UYGULAMA AYARLARI — FAZ 8 (sadakat oranı, rezervasyon süresi vb.)
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: text("user_id").default("1"),
  userName: text("user_name").default("Yönetici"),
  action: text("action").notNull(), // CREATE_ORDER, ADJUST_STOCK, CLOSE_SHIFT, ERP_SYNC, etc.
  entity: text("entity").notNull(), // Product, Inventory, Shift, Order
  entityId: text("entity_id"),
  details: text("details"),
  ipAddress: text("ip_address").default("127.0.0.1"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
