module.exports=[51223,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_role-matrix_route_actions_12s43j6.js.map