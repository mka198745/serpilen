module.exports=[54181,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_settings_route_actions_0htb5co.js.map