module.exports=[17334,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_warehouses_route_actions_0du7r55.js.map