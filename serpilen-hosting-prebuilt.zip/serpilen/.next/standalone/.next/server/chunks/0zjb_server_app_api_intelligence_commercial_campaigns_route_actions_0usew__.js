module.exports=[92379,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_campaigns_route_actions_0usew__.js.map