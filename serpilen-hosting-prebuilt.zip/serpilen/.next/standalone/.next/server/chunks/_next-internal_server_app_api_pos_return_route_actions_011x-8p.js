module.exports=[33771,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_return_route_actions_011x-8p.js.map