module.exports=[60463,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_inventory_abc-xyz_route_actions_0t9tgeu.js.map