module.exports=[70930,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_uploads_products_%5Bfile%5D_route_actions_0ok_7pr.js.map