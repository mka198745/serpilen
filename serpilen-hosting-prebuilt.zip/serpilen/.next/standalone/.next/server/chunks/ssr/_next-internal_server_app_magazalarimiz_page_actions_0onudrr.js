module.exports=[85565,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_magazalarimiz_page_actions_0onudrr.js.map