module.exports=[11410,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pos_page_actions_0d1s3ib.js.map