module.exports=[90895,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mimari_page_actions_12f..7g.js.map