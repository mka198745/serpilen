module.exports=[65606,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_anomalies_%5Bid%5D_route_actions_0t_ebl-.js.map