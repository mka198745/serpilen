module.exports=[15952,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_opportunities_%5Bid%5D_route_actions_0tvwa03.js.map