module.exports=[29200,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_customers_rfm_route_actions_0m3.95d.js.map