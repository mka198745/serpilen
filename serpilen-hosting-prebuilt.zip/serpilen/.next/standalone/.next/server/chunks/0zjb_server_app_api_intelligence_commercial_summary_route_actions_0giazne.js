module.exports=[3519,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_summary_route_actions_0giazne.js.map