module.exports=[10681,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment-settings_route_actions_04tkgfb.js.map