module.exports=[94522,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_quality_route_actions_0._lguk.js.map