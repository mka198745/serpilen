module.exports=[18455,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_handoff_route_actions_1389e4f.js.map