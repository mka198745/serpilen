module.exports=[35538,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_profitability_route_actions_0trvz02.js.map