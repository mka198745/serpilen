module.exports=[62592,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_accuracy_route_actions_0h8lrl2.js.map