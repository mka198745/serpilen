module.exports=[75311,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_settings_route_actions_10r5pzq.js.map