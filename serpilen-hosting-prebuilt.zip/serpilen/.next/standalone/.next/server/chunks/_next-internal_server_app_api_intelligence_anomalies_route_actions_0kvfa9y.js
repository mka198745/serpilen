module.exports=[30477,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_anomalies_route_actions_0kvfa9y.js.map