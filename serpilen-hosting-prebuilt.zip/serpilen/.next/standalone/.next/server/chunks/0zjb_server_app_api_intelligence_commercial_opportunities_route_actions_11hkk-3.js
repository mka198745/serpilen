module.exports=[9030,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_commercial_opportunities_route_actions_11hkk-3.js.map