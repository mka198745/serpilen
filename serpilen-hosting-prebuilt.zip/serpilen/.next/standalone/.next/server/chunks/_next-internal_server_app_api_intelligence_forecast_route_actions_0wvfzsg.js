module.exports=[3398,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_forecast_route_actions_0wvfzsg.js.map