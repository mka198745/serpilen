module.exports=[47926,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_intelligence_decision_settings_route_actions_0cogb-y.js.map