1:"$Sreact.fragment"
2:I[68718,["/_next/static/chunks/06ixel_1l0ynr.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0b1t56omv4f-y.js","/_next/static/chunks/0x51huuxxr2g4.js"],"OrderTrackClient"]
3:I[97367,["/_next/static/chunks/06ixel_1l0ynr.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0b1t56omv4f-y.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0x51huuxxr2g4.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"R8UztfUgBLBdKzb08Hqz7"}
5:null
