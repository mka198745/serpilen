:HL["/_next/static/chunks/0c67z2nah1iqt.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"iletisim","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"R8UztfUgBLBdKzb08Hqz7"}
