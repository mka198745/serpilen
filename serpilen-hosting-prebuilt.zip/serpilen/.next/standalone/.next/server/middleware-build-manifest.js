globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/R8UztfUgBLBdKzb08Hqz7/_buildManifest.js",
    "static/R8UztfUgBLBdKzb08Hqz7/_ssgManifest.js",
    "static/R8UztfUgBLBdKzb08Hqz7/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0h~lqnkna01or.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/02g3221oh~3le.js",
    "static/chunks/turbopack-0qmx71i-tgf4..js"
  ]
};
