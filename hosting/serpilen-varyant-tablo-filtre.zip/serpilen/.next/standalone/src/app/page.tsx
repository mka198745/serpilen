import React from "react";
import Link from "next/link";
import { db } from "@/db";
import { products, productVariants, categories, brands, inventory, blogPosts } from "@/db/schema";
import { ProductCard } from "@/components/storefront/ProductCard";
import { CategoryShowcase } from "@/components/storefront/CategoryShowcase";
import { CampaignStrip } from "@/components/storefront/CampaignStrip";
import { HeroProductActions } from "@/components/storefront/HeroProductActions";
import { getSiteSettings } from "@/lib/site-settings";
import { and, desc, eq, lte } from "drizzle-orm";
import {
  Scissors,
  Sliders,
  CircleDot,
  Ribbon,
  Sparkles,
  Layers,
  Handbag,
  Puzzle,
  Heart,
  ArrowRight,
  ShieldCheck,
  Truck,
  BookOpen,
  Star,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Fetch featured products with variants
  const allProds = await db.select().from(products);
  const allVars = await db.select().from(productVariants);
  const allCats = await db.select().from(categories);
  const allBrands = await db.select().from(brands);
  const siteSettings = await getSiteSettings();
  const blogEnabled = siteSettings["site.blog.enabled"] !== "false";
  const posts = blogEnabled
    ? await db.select().from(blogPosts)
        .where(and(eq(blogPosts.isPublished, true), lte(blogPosts.publishedAt, new Date())))
        .orderBy(desc(blogPosts.publishedAt), desc(blogPosts.id)).limit(3)
    : [];

  const featuredList = allProds.map((p) => {
    const vars = allVars.filter((v) => v.productId === p.id);
    const cat = allCats.find((c) => c.id === p.categoryId);
    const br = allBrands.find((b) => b.id === p.brandId);
    return {
      ...p,
      variants: vars,
      categoryName: cat?.name || "Kategori",
      brandName: br?.name || "Serpilen Collection",
    };
  });

  // Hero kartları yalnızca karşılık gelen aktif ürünler varsa gösterilir.
  const heroProducts = ["GUT-SEW-100", "YKK-MET-ZIP"]
    .map((sku) => featuredList.find((product) => product.sku === sku && product.isActive))
    .filter((product): product is NonNullable<typeof product> => Boolean(product));

  const categoryIcons = [
    { name: "Dikiş & Nakış", slug: "dikis-nakis", icon: Scissors, color: "from-amber-500 to-amber-700" },
    { name: "Fermuar Çeşitleri", slug: "fermuar", icon: Sliders, color: "from-sky-500 to-sky-700" },
    { name: "Düğme Dünyası", slug: "dugme", icon: CircleDot, color: "from-emerald-500 to-emerald-700" },
    { name: "Kurdele & Şerit", slug: "kurdele-serit", icon: Ribbon, color: "from-rose-500 to-rose-700" },
    { name: "Örgü & Hobi", slug: "orgu-hobi", icon: Sparkles, color: "from-purple-500 to-purple-700" },
    { name: "Çanta Aksesuarları", slug: "canta-aksesuarlari", icon: Handbag, color: "from-fuchsia-500 to-fuchsia-700" },
    { name: "Tekstil Yardımcı", slug: "tekstil-yardimci", icon: Layers, color: "from-teal-500 to-teal-700" },
    { name: "Hobi Kitleri", slug: "hobi-kitleri", icon: Puzzle, color: "from-indigo-500 to-indigo-700" },
    { name: "El İşi Ürünler", slug: "el-isi-urunler", icon: Heart, color: "from-pink-500 to-pink-700" },
  ];

  // Yalnızca aktif kategorilerdeki aktif ürünler anasayfa kategorilerini görünür kılar.
  const activeProductsByCategory = new Map<number, typeof featuredList>();
  for (const product of featuredList) {
    if (!product.isActive) continue;
    const items = activeProductsByCategory.get(product.categoryId) ?? [];
    items.push(product);
    activeProductsByCategory.set(product.categoryId, items);
  }
  const availableCategories = new Map(
    allCats
      .filter((cat) => cat.isActive && (activeProductsByCategory.get(cat.id)?.length ?? 0) > 0)
      .map((cat) => [cat.slug, cat]),
  );
  const visibleCategoryIcons = categoryIcons.filter((cat) => availableCategories.has(cat.slug));

  // "Günün Öne Çıkan Ürünleri" yalnızca öne çıkanları gösterir (en fazla 8).
  // Hiçbiri işaretli değilse ilk 8 ürün gösterilir; kategori vitrinleri tüm ürünleri kullanır.
  const featuredFlagged = featuredList.filter((p) => p.isFeatured);
  const featuredGrid = (featuredFlagged.length > 0 ? featuredFlagged : featuredList).slice(0, 8);

  /** Anasayfa kategori vitrinleri — sıra kullanıcı isteğine göre sabittir. */
  const showcaseDefs = [
    { slug: "el-isi-urunler", title: "El İşi Ürünler", eyebrow: "El Emeği" },
    { slug: "hobi-kitleri", title: "Hobi Kitleri", eyebrow: "Başlangıç Setleri" },
    { slug: "orgu-hobi", title: "Örgü & Hobi", eyebrow: "İplik, Şiş & Tığ" },
    { slug: "dikis-nakis", title: "Dikiş & Nakış", eyebrow: "İplik & İğne" },
    { slug: "canta-aksesuarlari", title: "Çanta Aksesuarları", eyebrow: "Toka, Sap & Çıtçıt" },
    { slug: "fermuar", title: "Fermuar Çeşitleri", eyebrow: "Metal, Spiral & Gizli" },
    { slug: "kurdele-serit", title: "Kurdele & Şerit", eyebrow: "Saten, Grogren & Jüt" },
    { slug: "dugme", title: "Düğme Dünyası", eyebrow: "Sedef, Ahşap & Metal" },
    { slug: "tekstil-yardimci", title: "Tekstil Yardımcı Ürünleri", eyebrow: "Tela, Lastik & Cırt" },
  ];

  return (
    <div className="space-y-12 md:space-y-16 pb-16">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-amber-950 via-stone-900 to-stone-950 text-white py-12 md:py-20 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          {/* Vitrin ürünleri: butonlar gerçek ürün kaydını kullanır. */}
          {heroProducts.length > 0 && <div className="lg:col-span-7">
            <div className={`grid grid-cols-1 ${heroProducts.length > 1 ? "sm:grid-cols-2" : "sm:max-w-md"} gap-4`}>
              {heroProducts.map((product) => (
                <article key={product.id} className="relative bg-stone-900/90 rounded-3xl p-3 border border-stone-800 shadow-2xl backdrop-blur-md">
                  <div className="relative aspect-4/5 sm:aspect-4/3 rounded-2xl overflow-hidden border border-stone-700/60">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={product.imageUrl || "https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=800&auto=format&fit=crop&q=80"} alt={product.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex items-end p-4">
                      <div>
                        <span className="bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Vitrin Öne Çıkan</span>
                        <h3 className="text-white font-bold text-sm sm:text-base mt-1 leading-snug">{product.name}</h3>
                      </div>
                    </div>
                  </div>
                  <HeroProductActions product={product} initialCartEnabled={siteSettings["site.cart.enabled"] !== "false"} />
                </article>
              ))}
            </div>
          </div>}

          {/* Right: Başlık */}
          <div className={`${heroProducts.length ? "lg:col-span-5" : "lg:col-span-12"} space-y-6`}>
            <h1 className="text-3xl sm:text-4xl md:text-5xl xl:text-6xl font-black tracking-tight leading-[1.1]">
              Dikiş, Nakış ve Hobi Dünyasında <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
                Usta İmzası Kalite.
              </span>
            </h1>
          </div>
        </div>
      </section>

      {/* 2. Mega Categories Grid */}
      {visibleCategoryIcons.length > 0 && <section className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              Kapsamlı Ürün Ağacı
            </span>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Öne Çıkan Tuhafiye Kategorileri
            </h2>
          </div>
          <Link
            href="/urunler"
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 flex items-center gap-1"
          >
            <span>Tümünü Gör</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-3">
          {visibleCategoryIcons.map((cat) => {
            const Icon = cat.icon;
            const category = availableCategories.get(cat.slug)!;
            const productCount = activeProductsByCategory.get(category.id)!.length;
            return (
              <Link
                key={cat.slug}
                href={`/urunler?category=${cat.slug}`}
                className="group bg-white p-4 rounded-2xl border border-gray-100 hover:border-amber-300 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col items-center text-center"
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cat.color} text-white flex items-center justify-center mb-3 group-hover:scale-110 transition`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xs font-bold text-gray-900 group-hover:text-amber-800 transition line-clamp-1">
                  {cat.name}
                </h3>
                <span className="text-[10px] text-gray-400 mt-1">{productCount} Ürün</span>
              </Link>
            );
          })}
        </div>
      </section>}

      {/* 3. Featured Products Grid */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              Popüler ve Çok Satanlar
            </span>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Günün Öne Çıkan Ürünleri
            </h2>
          </div>
          <Link
            href="/urunler"
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 flex items-center gap-1"
          >
            <span>Katalogda Keşfet</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredGrid.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 3.1 Kategori Vitrinleri — her kategoriden en fazla 4 ürün */}
      {showcaseDefs.map((showcase) => {
        const cat = availableCategories.get(showcase.slug);
        if (!cat) return null;
        const items = [...(activeProductsByCategory.get(cat.id) ?? [])]
          .sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || a.id - b.id)
          .slice(0, 4);
        return (
          <CategoryShowcase
            key={showcase.slug}
            eyebrow={showcase.eyebrow}
            title={showcase.title}
            href={`/urunler?category=${showcase.slug}`}
            products={items}
          />
        );
      })}

      {/* 3.5 FAZ 8: Aktif Kampanya Şeridi */}
      <CampaignStrip />

      {/* 5. Sewing & Craft Blog Guide Preview */}
      {blogEnabled && <section className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              Bilgi & Atölye
            </span>
            <h2 className="text-2xl font-black text-gray-900 tracking-tight">
              Dikiş, Fermuar & Malzeme Rehberi
            </h2>
          </div>
          <Link
            href="/blog"
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 flex items-center gap-1"
          >
            <span>Tüm Makaleler</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {posts.length === 0 && <p className="col-span-full text-sm text-stone-500">Henüz yayında içerik yok — yakında yeni rehberler eklenecek.</p>}
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xs hover:shadow-lg transition flex flex-col"
            >
              <div className="aspect-16/9 bg-gray-100 overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={post.imageUrl || "https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=600"}
                  alt={post.title}
                  className="w-full h-full object-cover hover:scale-105 transition duration-500"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                    {post.category}
                  </span>
                  <h3 className="font-bold text-sm text-gray-900 mt-2 line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-2 line-clamp-2 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-400">
                  <span>{post.author}</span>
                  <Link href={`/blog/${post.slug}`} className="font-semibold text-amber-800 hover:underline">
                    Devamını Oku →
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>}
    </div>
  );
}
