import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import { AuthProvider } from "@/context/AuthContext";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { CartDrawer } from "@/components/layout/CartDrawer";
import { AuthModal } from "@/components/layout/AuthModal";
import { PrivacyNotice } from "@/components/layout/PrivacyNotice";
import { getSiteSettings } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://serpilencollection.com"),
  title: "Serpilen Collection | Dikiş, Nakış, Fermuar, Düğme & Örgü Malzemeleri",
  description:
    "Türkiye'nin lider tuhafiye ve tekstil hobi malzemeleri platformu. Gütermann, Coats, YKK ve Prym ürünlerinde perakende satış ve hızlı kargo.",
  keywords: [
    "tuhafiye",
    "dikiş ipliği",
    "ykk fermuar",
    "gütermann",
    "düğme",
    "saten kurdele",
    "alize örgü ipi",
    "terzi makası",
    "bez tela",
    "pos kasa",
  ],
  authors: [{ name: "Serpilen Collection San. ve Tic. Ltd. Şti." }],
  openGraph: {
    title: "Serpilen Collection | Perakende & POS Dijital Platformu",
    description: "Fiziki mağaza, online e-ticaret ve çoklu depo stok entegrasyonu.",
    locale: "tr_TR",
    type: "website",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = await getSiteSettings();
  const blogEnabled = settings["site.blog.enabled"] !== "false";
  return (
    <html lang="tr" className="scroll-smooth">
      <head>
        {/* Schema.org Organization JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "Serpilen Collection",
              image: "https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=800",
              telephone: "08508882026",
              email: "siparis@serpilencollection.com",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Moda Caddesi No: 18",
                addressLocality: "Kadıköy",
                addressRegion: "İstanbul",
                postalCode: "34710",
                addressCountry: "TR",
              },
              currenciesAccepted: "TRY",
              paymentAccepted: "Cash, Credit Card, Bank Transfer",
              priceRange: "₺₺",
            }),
          }}
        />
      </head>
      <body className="min-h-screen bg-stone-50 text-stone-900 flex flex-col antialiased selection:bg-amber-800 selection:text-white">
        <CartProvider>
          <AuthProvider>
            <Header initialBlogEnabled={blogEnabled} />
            <main className="flex-1">{children}</main>
            <CartDrawer />
            <AuthModal />
            <Footer initialBlogEnabled={blogEnabled} />
            <PrivacyNotice />
          </AuthProvider>
        </CartProvider>
      </body>
    </html>
  );
}
