module.exports=[97740,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crm_customers_%5Bid%5D_orders_route_actions_0npqjhr.js.map