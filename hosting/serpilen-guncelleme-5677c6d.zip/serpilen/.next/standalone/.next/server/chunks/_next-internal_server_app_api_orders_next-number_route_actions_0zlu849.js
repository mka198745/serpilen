module.exports=[74992,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orders_next-number_route_actions_0zlu849.js.map