module.exports=[75311,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_settings_route_actions_1xjnpel-5vnat.js.map