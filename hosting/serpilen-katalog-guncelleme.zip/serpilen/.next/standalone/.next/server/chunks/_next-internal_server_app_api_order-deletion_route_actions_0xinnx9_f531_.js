module.exports=[52468,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order-deletion_route_actions_0xinnx9_f531_.js.map