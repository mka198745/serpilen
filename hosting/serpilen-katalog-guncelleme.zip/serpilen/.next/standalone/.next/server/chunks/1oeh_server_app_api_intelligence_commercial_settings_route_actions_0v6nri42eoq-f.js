module.exports=[54181,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_intelligence_commercial_settings_route_actions_0v6nri42eoq-f.js.map