module.exports=[81477,e=>{"use strict";e.s(["f",0,function(e){if(!/^\d{4}-\d{2}-\d{2}$/.test(e))return null;let t=Date.parse(`${e}T00:00:00.000Z`);return Number.isFinite(t)&&new Date(t).toISOString().slice(0,10)===e?t/1e3:null}])}];

//# sourceMappingURL=src_lib_crm-date_ts_1uebzug-7kxcp._.js.map