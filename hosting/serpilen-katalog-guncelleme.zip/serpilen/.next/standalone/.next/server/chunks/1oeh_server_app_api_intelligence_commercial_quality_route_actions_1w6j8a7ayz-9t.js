module.exports=[94522,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_intelligence_commercial_quality_route_actions_1w6j8a7ayz-9t.js.map