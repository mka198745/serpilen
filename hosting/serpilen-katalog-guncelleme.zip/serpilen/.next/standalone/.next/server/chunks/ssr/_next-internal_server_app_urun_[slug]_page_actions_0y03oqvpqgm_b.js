module.exports=[31552,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_urun_%5Bslug%5D_page_actions_0y03oqvpqgm_b.js.map