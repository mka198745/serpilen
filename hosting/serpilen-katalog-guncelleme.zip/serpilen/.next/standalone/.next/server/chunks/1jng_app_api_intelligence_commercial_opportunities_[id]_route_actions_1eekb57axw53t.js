module.exports=[15952,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_intelligence_commercial_opportunities_%5Bid%5D_route_actions_1eekb57axw53t.js.map