module.exports=[62592,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_accuracy_route_actions_0u9-paimej-z8.js.map