module.exports=[50660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_sale_route_actions_011gjeuu2msls.js.map