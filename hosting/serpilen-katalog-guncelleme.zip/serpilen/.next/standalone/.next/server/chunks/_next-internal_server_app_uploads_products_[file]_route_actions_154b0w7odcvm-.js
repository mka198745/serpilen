module.exports=[70930,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_uploads_products_%5Bfile%5D_route_actions_154b0w7odcvm-.js.map