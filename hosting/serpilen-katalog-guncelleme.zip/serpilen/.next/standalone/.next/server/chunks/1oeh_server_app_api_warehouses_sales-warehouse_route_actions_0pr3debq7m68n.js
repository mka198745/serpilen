module.exports=[97670,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_warehouses_sales-warehouse_route_actions_0pr3debq7m68n.js.map