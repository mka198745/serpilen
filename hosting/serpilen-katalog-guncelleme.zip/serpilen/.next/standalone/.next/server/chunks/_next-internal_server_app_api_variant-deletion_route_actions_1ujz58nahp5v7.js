module.exports=[44576,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_variant-deletion_route_actions_1ujz58nahp5v7.js.map