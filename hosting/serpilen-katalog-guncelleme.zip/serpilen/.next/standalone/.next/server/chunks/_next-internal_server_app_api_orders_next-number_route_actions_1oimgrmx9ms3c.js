module.exports=[74992,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orders_next-number_route_actions_1oimgrmx9ms3c.js.map