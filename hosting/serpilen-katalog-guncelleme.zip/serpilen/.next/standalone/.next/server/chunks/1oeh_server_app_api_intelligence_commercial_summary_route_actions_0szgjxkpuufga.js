module.exports=[3519,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_intelligence_commercial_summary_route_actions_0szgjxkpuufga.js.map