module.exports=[79212,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_quote_route_actions_1sasx1bfzocro.js.map