module.exports=[67164,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_product-variant-edit_route_actions_1nl__2r9ld3_6.js.map