module.exports=[9030,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_intelligence_commercial_opportunities_route_actions_1ywdanaucc-q1.js.map