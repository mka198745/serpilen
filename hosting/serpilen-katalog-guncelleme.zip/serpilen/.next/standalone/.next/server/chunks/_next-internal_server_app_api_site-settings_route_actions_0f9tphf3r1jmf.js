module.exports=[40261,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_site-settings_route_actions_0f9tphf3r1jmf.js.map