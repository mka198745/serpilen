module.exports=[54009,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_access_route_actions_1ge94koznlja-.js.map