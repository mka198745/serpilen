module.exports=[27451,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_bootstrap_route_actions_0dhnuieq86qmp.js.map