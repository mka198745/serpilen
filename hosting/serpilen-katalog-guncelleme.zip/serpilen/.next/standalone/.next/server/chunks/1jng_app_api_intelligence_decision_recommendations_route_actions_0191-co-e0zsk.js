module.exports=[1210,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_api_intelligence_decision_recommendations_route_actions_0191-co-e0zsk.js.map