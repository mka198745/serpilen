module.exports=[9556,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_siparis-takip_page_actions_0rgiydm-0iu6x.js.map