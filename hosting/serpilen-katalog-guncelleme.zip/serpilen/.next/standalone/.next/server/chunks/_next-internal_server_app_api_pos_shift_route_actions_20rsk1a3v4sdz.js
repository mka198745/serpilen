module.exports=[55417,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_shift_route_actions_20rsk1a3v4sdz.js.map