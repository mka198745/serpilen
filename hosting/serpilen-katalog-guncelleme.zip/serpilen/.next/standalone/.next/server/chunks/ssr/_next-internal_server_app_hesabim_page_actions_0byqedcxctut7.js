module.exports=[26738,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hesabim_page_actions_0byqedcxctut7.js.map