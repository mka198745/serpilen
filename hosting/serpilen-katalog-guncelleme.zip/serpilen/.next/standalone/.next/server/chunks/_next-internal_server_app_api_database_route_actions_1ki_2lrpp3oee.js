module.exports=[7681,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_database_route_actions_1ki_2lrpp3oee.js.map