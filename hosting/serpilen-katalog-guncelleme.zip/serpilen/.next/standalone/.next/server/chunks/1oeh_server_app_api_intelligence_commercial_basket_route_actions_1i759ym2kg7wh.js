module.exports=[26202,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_intelligence_commercial_basket_route_actions_1i759ym2kg7wh.js.map