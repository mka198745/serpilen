module.exports=[51223,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_role-matrix_route_actions_1-2w0kk5qogaa.js.map