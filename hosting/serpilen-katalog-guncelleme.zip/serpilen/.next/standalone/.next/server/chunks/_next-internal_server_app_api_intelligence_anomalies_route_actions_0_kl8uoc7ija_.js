module.exports=[30477,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_intelligence_anomalies_route_actions_0_kl8uoc7ija_.js.map