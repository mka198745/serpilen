module.exports=[34978,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pos_order_route_actions_11mgxxuba4evx.js.map